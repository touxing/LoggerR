import './webworker.d.ts'
export {};
declare global {
   interface Window {
    Logger: any
  }
}